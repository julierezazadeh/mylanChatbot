'use strict';

// Imports dependencies and set up http server
const express = require('express')
const bodyParser = require('body-parser')
const request = require('request')
const app = express()

app.set('port', (process.env.PORT || 1337))
console.log('webhook is listening')

//Allows us to process the data
app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())

//ROUTES
app.get('/', function(req, res) {
  res.send("Hi, I am a chatbot.")
})

//facebook webhook calls
app.get('/webhook_en/', function(req, res) {
  if(req.query['hub.verify_token'] === "<YOUR_VERIFY_TOKEN>") {
    res.send(req.query['hub.challenge'])
    console.log('Web-Token Verified')
  } else {
  res.send("Wrong token. Please try again.")
  }
})

app.get('/webhook_fr/', function(req, res) {
  if(req.query['hub.verify_token'] === "<YOUR_VERIFY_TOKEN>") {
    res.send(req.query['hub.challenge'])
    console.log('Web-Token vérifié')
  } else {
  res.send("l'information est incorrecte. Veuillez réessayer")
  }
})


//Webhook Calls & Chatbot Functionality
app.post('/webhook_en/', function(req, res) {
  processHook(req, res, "en");
});

app.post('/webhook_fr/', function(req, res) {
      processHook(req, res, "fr");
});


//Functions & Question Cases
function processHook(req, res, lang) {

  const Localize = require('localize');
  let localize = new Localize('./translations');
  localize.setLocale(lang);

  let messaging_events = req.body.entry[0].messaging
  for (let i = 0; i < messaging_events.length; i++) {
    let event = messaging_events[i]
    let sender = event.sender.id
    if (event.message && event.message.text && event.message.nlp) {
      let text = event.message.text
      let nlp = event.message.nlp
      let greetings = event.message.nlp.entities.greetings
      let thanks = event.message.nlp.entities.thanks

      console.dir(event.message); //look for events
      console.log(event.message.nlp.entities);
      //console.log(event.message.nlp.entities.greetings);
      //console.log(event.message.nlp.entities.thanks);
      //main entry points

      if(greetings) {
        // handle a greeting
        console.log('LOCALIZED TEXT:', localize.translate("Hi there!"), lang);
        sendText(sender, localize.translate("Hi there!"), lang);
      }

      if(thanks) {
        // handle thank-you's
        console.log('LOCALIZED TEXT:', localize.translate("No problem!"), lang);
        sendText(sender, localize.translate("No problem!"), lang);
      }


      if (event.message.nlp && event.message.nlp.entities && event.message.nlp.entities.intent) {
        let value = event.message.nlp.entities.intent[0]["value"];
        console.log('THE VALUE IS:', value);
        let condition = event.message.nlp.entities.condition; // [0]["value"];
        console.log('THE CONDITION IS:', condition);

        // handle untrained expressions with fallback message
        /*if (!(value && condition)) {
          //handle messages not yet trained
          console.log('FRENCH TEXT:', localize.translate("Sorry, I didn't understand what you meant. This is awkward..", lang));
          sendText(sender, localize.translate("Sorry, I didn't understand what you meant. This is awkward..", lang));
        }*/

        if (value && condition) {
          //console.dir(event.message.nlp.entities.intent[0]["value"]);
          switch(value && condition[0]["value"]) {
            case "get_answer" && "hypothyroidism":
              sendText(sender, "Hypothyroidism, also called underactive thyroid or low thyroid, is a disorder of the endocrine system in which the thyroid gland does not produce enough thyroid hormone. It can cause a number of symptoms, such as poor ability to tolerate cold, a feeling of tiredness, constipation, depression, and weight gain.", lang);
              break;
            case "get_answer" && "hyperthyroidism":
              sendText(sender, "Hyperthyroidism (overactive thyroid) is a condition in which your thyroid gland produces too much of the hormone thyroxine. Hyperthyroidism can accelerate your body's metabolism significantly, causing sudden weight loss, a rapid or irregular heartbeat, sweating, and nervousness or irritability.", lang);
              break;
            case "explain_difference" && "difference":
              sendText(sender, "“Hypo” means low or under what is normal, whereas “hyper” means high or above what is normal. So hypothyroidism means the thyroid is underactive and hyperthyroidism means the thyroid is overactive.", lang);
              break;
            default:
            return false;
          }
         }
      }
    }
  }
  res.sendStatus(200)
};


function profanityFilter(text) {

  switch (text) {
    case "fuck you":
    return text;
    case "fuck off":
    return text;
    case "asshole":
    return text;
    case "shit":
    return text;
    case "bitch":
    return text;

    default:
      return false
  }
}


function sanitze(text) {
  //This function is sanitzing correctly however only returns the first answer for any input inlcuding gibberish
  //Answers the first question regardless of spaces, punctuation, and caps.
  text.replace(/\s*([,.!?:;])[,.!?:;]*\s*/g,'$1 ') //This removes all the punctuations
  text.replace(/(?:^|[^a-z])([A-Z]+)(?:[^a-z]|$)/g,function(v){return v.toLowerCase();}) //Upper case to lower case
  text.replace(/\s*$/,"") //Trimming the right end
  //console.log(text);
}


function sendText(sender, text, lang) {
  let messageData = {text: text}
  if (lang === "fr") {
    // French Page Access Token
    let accessToken = "EAADibNkK6iABABRUjKw0nW827aefrhQmr1FbYS2I2rwZBBW6ZCnYahzjLHZANYsiWRXxE87p0UL38zmRDHt9e4QLbpQuFwXw2CR1ttbbiBjeWB9FD2DVqhy89TG5LSFedhMPPCF7dETZCZAOxV8eyEqkJT91GTb0jjZA5Rh6nt7IwD79s2YDfCkLLRISk327wZD";

    request({
      "url": "https://graph.facebook.com/v2.6/me/messages",
      "qs": { "access_token" : accessToken },
      "method": "POST",
      "json": {
        "recipient": {id: sender},
        "message" : messageData
      }
    }, function(error, response, body) {
      if (error) {
        console.log("sending error")
      } else if (response.body.error) {
        //console.log("response body error")
      }
    })

  } else {
    // English Page Access Token
    let accessToken = "EAAD7mg7dRqsBANKLZAWZC47lc5zhoxDFLPNkFYza8fzjZAee1GVfgOmaV2xaJLtEqfKZAq2YXritLqsOuZAHBQvHiKqn8tldKgOtyE9r00pdZBcSBFZAH49r2zekJSek7MZCCvpiu0rnZCwZCd0dzsmWxfZCUP6lN94Xz7cGWXae590PQ5ZCAx8Qi4ZBZCrHZBjzC0VTL8ZD";

  request({
    "url": "https://graph.facebook.com/v2.6/me/messages",
    "qs": { "access_token" : accessToken },
    "method": "POST",
    "json": {
      "recipient": {id: sender},
      "message" : messageData
    }
  }, function(error, response, body) {
    if (error) {
      console.log("sending error")
    } else if (response.body.error) {
      //console.log("response body error")
    }
  })
}
}

//Listeners
app.listen(app.get('port'), function() {
  console.log("Running: Port")
})
